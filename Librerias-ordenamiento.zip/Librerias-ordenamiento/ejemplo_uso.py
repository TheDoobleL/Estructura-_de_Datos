from metodos_ordenamiento import (
    burbuja,
    heapsort,
    insercion,
    quicksort,
    radix,
    seleccion,
    shellsort
)

# Lista de ejemplo para ordenar
arr = [170, 45, 75, 90, 802, 24, 2, 66]

print("\n=== Resultados de Ordenamiento ===")
print(f"Original: {arr}")

# Aseguramos que cada llamada use una copia para no afectar la lista original
print(f"\nBurbuja:   {burbuja(arr.copy())}")
print(f"Inserción: {insercion(arr.copy())}")  # Capitalizado
print(f"Selección: {seleccion(arr.copy())}")  # Capitalizado y acentuado
print(f"ShellSort: {shellsort(arr.copy())}")
print(f"Quicksort: {quicksort(arr.copy())}")  # Capitalizado
print(f"Heapsort:  {heapsort(arr.copy())}")   # Capitalizado
print(f"Radix:     {radix(arr.copy())}")      # Capitalizado