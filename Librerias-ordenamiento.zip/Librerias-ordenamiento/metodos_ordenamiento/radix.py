def ordenar(arr):
    if not arr:  # Maneja listas vacías
        return arr
        
    max_num = max(arr)
    exp = 1
    
    def counting_sort(arr, exp):
        n = len(arr)
        output = [0] * n
        count = [0] * 10  # Para dígitos 0-9
        
        # Contar ocurrencias de cada dígito
        for i in range(n):
            index = (arr[i] // exp) % 10
            count[index] += 1
            
        # Acumular count
        for i in range(1, 10):
            count[i] += count[i-1]
            
        # Construir output
        i = n - 1
        while i >= 0:
            index = (arr[i] // exp) % 10
            output[count[index] - 1] = arr[i]
            count[index] -= 1
            i -= 1
            
        return output
    
    # Aplicar counting_sort para cada dígito
    while max_num // exp > 0:
        arr = counting_sort(arr, exp)
        exp *= 10
        
    return arr