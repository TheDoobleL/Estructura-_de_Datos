from .burbuja import ordenar as burbuja
from .heapsort import ordenar as heapsort
from .insercion import ordenar as insercion
from .quicksort import ordenar as quicksort
from .radix import ordenar as radix  
from .seleccion import ordenar as seleccion 
from .shellsort import ordenar as shellsort

__all__ = [
    'burbuja',
    'heapsort',
    'insercion',
    'quicksort',
    'radix',
    'selection',
    'shellsort'
]